class FaKeys{
  static const String kEventPurchase = "purchase";
}