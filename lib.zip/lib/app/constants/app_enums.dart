enum DiscountType{
  fixed,
  percentage
}

enum AdOnType { free, range, paid }


enum PaymentMethodType {
  onlinePay,
  applePay,
  walletPay,
  tabby,
  notSelected,
}
