import 'package:auto_route/auto_route.dart';
import 'package:fennac_app/routes/routes_imports.gr.dart';
import 'package:flutter/material.dart';

part 'routes.dart';
