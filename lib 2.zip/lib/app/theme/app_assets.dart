class AppAssets {
  AppAssets._();
 
}
