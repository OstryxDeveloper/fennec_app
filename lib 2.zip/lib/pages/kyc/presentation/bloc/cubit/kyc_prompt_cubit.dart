import 'dart:developer';
import 'dart:io';
import 'dart:async';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:fennac_app/pages/kyc/presentation/bloc/state/kyc_prompt_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

class AudioPromptData {
  final String audioPath;
  final List<double> waveformData;
  final String duration;

  AudioPromptData({
    required this.audioPath,
    required this.waveformData,
    required this.duration,
  });
}

class KycPromptCubit extends Cubit<KycPromptState> {
  KycPromptCubit() : super(KycPromptInitial());

  // List of predefined prompts
  final List<String> predefinedPrompts = [
    'A perfect weekend for me looks like...',
    'The most spontaneous thing I\'ve done...',
    'My friends describe me as...',
    'Two truths and a lie...',
    'What I\'d bring to a group trip...',
    'The fastest way to make me smile...',
    'How my group describes me in one word...',
    'My ideal group activity is...',
  ];

  final TextEditingController promptController = TextEditingController();
  final TextEditingController controller = TextEditingController();
  List<double> recordedWaveformData = [];
  String recordedDuration = '00:00';

  // Selected prompts (up to 4)
  final List<String> selectedPrompts = [];

  // Custom prompts created by user
  final List<String> customPrompts = [];

  // Prompt answers: Map<prompt, answer>
  // Answer can be text (String) or audio path (String starting with '/')
  final Map<String, String> promptAnswers = {};

  // Audio paths for prompts: Map<prompt, audioPath>
  final Map<String, String> promptAudioPaths = {};

  // Audio prompt data with waveform and duration: Map<prompt, AudioPromptData>
  final Map<String, AudioPromptData> audioPromptData = {};

  // Maximum allowed prompts
  static const int maxPrompts = 4;

  // Bottom sheet visibility
  bool _showBottomSheet = false;
  bool get showBottomSheet => _showBottomSheet;

  bool isAudioMode = false;

  // Audio recorder and player managed by cubit
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  // Recording/playback state
  String? recordingPath;
  bool isRecording = false;
  bool isRecordingPaused = false;
  bool isRecorded = false;
  bool isPlaying = false;

  // Real-time waveform capture
  final List<double> _waveformBuffer = [];
  final int _maxWaveformSamples = 200; // Limit buffer for memory efficiency
  StreamSubscription<Amplitude>? _recordSubscription;

  // Timers
  Timer? _recordTimer;
  Duration recordingElapsed = Duration.zero;

  // Getters for public access
  AudioRecorder get recorder => _recorder;
  AudioPlayer get player => _player;
  List<double> get waveformBuffer => _waveformBuffer;

  void toggleAudioMode() {
    emit(KycPromptLoading());
    isAudioMode = !isAudioMode;
    emit(KycPromptLoaded());
  }

  Future<void> startRecording() async {
    try {
      emit(KycPromptLoading());

      // Check microphone permission
      if (!(await _recorder.hasPermission())) {
        log("Microphone permission denied");
        emit(KycPromptError());
        return;
      }

      final directory = await path_provider.getApplicationDocumentsDirectory();
      final path =
          '${directory.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

      // Cancel any existing subscription
      await _recordSubscription?.cancel();

      // Start recording and capture amplitude stream
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: path,
      );

      recordingPath = path;
      isRecording = true;
      isRecordingPaused = false;
      isRecorded = false;
      isPlaying = false;
      _waveformBuffer.clear();
      recordingElapsed = Duration.zero;

      // Start timer
      _recordTimer?.cancel();
      _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        recordingElapsed += const Duration(seconds: 1);
        emit(KycPromptLoaded());
      });

      // Capture amplitude stream for waveform
      _recordSubscription = _recorder
          .onAmplitudeChanged(const Duration(milliseconds: 100))
          .listen(
            (amplitude) {
              _captureWaveformAmplitude(amplitude);
              emit(KycPromptLoaded());
            },
            onError: (e) {
              log("Amplitude stream error: $e");
            },
          );

      emit(KycPromptLoaded());
    } catch (e) {
      log("Error starting recording: $e");
      emit(KycPromptError());
      rethrow;
    }
  }

  /// Capture and normalize amplitude values for waveform visualization
  void _captureWaveformAmplitude(Amplitude amplitude) {
    // amplitude.current is the current amplitude in dBFS
    final dB = amplitude.current;

    // Normalize amplitude (0-1 range)
    // RecordEvent amplitude is typically -160 to 0 dB
    // Normalize to 0-1: (dB + 160) / 160
    final normalized = ((dB + 160) / 160).clamp(0.0, 1.0);

    // Apply smoothing to reduce jitter
    if (_waveformBuffer.isNotEmpty) {
      final lastValue = _waveformBuffer.last;
      final smoothed = (lastValue * 0.6 + normalized * 0.4); // 60/40 smoothing
      _waveformBuffer.add(smoothed);
    } else {
      _waveformBuffer.add(normalized);
    }

    // Limit buffer size for memory efficiency
    if (_waveformBuffer.length > _maxWaveformSamples) {
      _waveformBuffer.removeAt(0);
    }
  }

  Future<void> stopRecording() async {
    try {
      log("Stopping recording...");
      emit(KycPromptLoading());

      // Stop recording
      final path = await _recorder.stop();
      recordingPath = path ?? recordingPath;

      // Cancel amplitude stream
      await _recordSubscription?.cancel();
      _recordSubscription = null;

      isRecording = false;
      isRecordingPaused = false;
      isRecorded = true;
      isPlaying = false;

      // Finalize timer
      _recordTimer?.cancel();

      // Use captured waveform buffer
      if (_waveformBuffer.isNotEmpty) {
        recordedWaveformData = List<double>.from(_waveformBuffer);
        log("✅ Captured ${recordedWaveformData.length} waveform samples");
      } else {
        log("⚠️ No waveform data captured, generating fallback");
        recordedWaveformData = List.generate(100, (i) {
          final t = i / 100.0;
          return (0.3 + 0.7 * (1 - (2 * t - 1).abs())) *
              (0.5 + 0.5 * (i % 3) / 3);
        });
      }

      // Format duration
      final minutes = (recordingElapsed.inSeconds ~/ 60).toString().padLeft(
        2,
        '0',
      );
      final seconds = (recordingElapsed.inSeconds % 60).toString().padLeft(
        2,
        '0',
      );
      recordedDuration = '$minutes:$seconds';

      emit(KycPromptLoaded());
    } catch (e) {
      log("Error stopping recording: $e");
      emit(KycPromptError());
      rethrow;
    }
  }

  Future<void> playPreview() async {
    try {
      emit(KycPromptLoading());
      if (recordingPath == null) {
        emit(KycPromptLoaded());
        return;
      }

      // Use ProgressiveAudioSource with file:// URI
      final audioSource = ProgressiveAudioSource(Uri.file(recordingPath!));

      await _player.setAudioSource(audioSource);
      await _player.play();
      isPlaying = true;

      // Listen for playback completion
      _player.playerStateStream.listen((state) {
        if (!state.playing &&
            state.processingState == ProcessingState.completed) {
          isPlaying = false;
          emit(KycPromptLoaded());
        }
      });

      emit(KycPromptLoaded());
    } catch (e) {
      log("Error playing preview: $e");
      emit(KycPromptError());
      rethrow;
    }
  }

  Future<void> pausePreview() async {
    try {
      if (!isPlaying) return;
      emit(KycPromptLoading());
      await _player.pause();
      isPlaying = false;
      emit(KycPromptLoaded());
    } catch (e) {
      log("Error pausing preview: $e");
      emit(KycPromptError());
      rethrow;
    }
  }

  Future<void> stopPreview() async {
    try {
      emit(KycPromptLoading());
      await _player.stop();
      isPlaying = false;
      emit(KycPromptLoaded());
    } catch (e) {
      log("Error stopping preview: $e");
      emit(KycPromptError());
      rethrow;
    }
  }

  void deleteAudio() {
    emit(KycPromptLoading());
    try {
      // Stop playback and recording (use catchError for safety)
      _player.stop().catchError((_) {});
      _recorder.stop().catchError((_) => null);

      // Cancel streams
      _recordSubscription?.cancel();
      _recordSubscription = null;
      _recordTimer?.cancel();

      recordingElapsed = Duration.zero;

      if (recordingPath != null) {
        try {
          final file = File(recordingPath!);
          if (file.existsSync()) {
            file.deleteSync();
          }
        } catch (e) {
          log("Error deleting audio file: $e");
        }
      }

      recordingPath = null;
      isRecorded = false;
      isPlaying = false;
      isRecording = false;
      isRecordingPaused = false;
      recordedWaveformData = [];
      recordedDuration = '00:00';
      _waveformBuffer.clear();

      emit(KycPromptLoaded());
    } catch (e) {
      log("Error deleting audio: $e");
      emit(KycPromptError());
    }
  }

  @override
  Future<void> close() async {
    // Cleanup on cubit disposal
    _recordSubscription?.cancel();
    _recordTimer?.cancel();
    await _recorder.stop();
    await _player.dispose();
    return super.close();
  }

  void showCreatePromptBottomSheet() {
    emit(KycPromptLoading());
    _showBottomSheet = true;
    emit(KycPromptLoaded());
  }

  void hideCreatePromptBottomSheet() {
    emit(KycPromptLoading());
    _showBottomSheet = false;
    emit(KycPromptLoaded());
  }

  void togglePromptSelection(String prompt) {
    emit(KycPromptLoading());
    if (selectedPrompts.contains(prompt)) {
      selectedPrompts.remove(prompt);
    } else {
      if (selectedPrompts.length < maxPrompts) {
        selectedPrompts.add(prompt);
      }
    }
    emit(KycPromptLoaded());
  }

  void addCustomPrompt(String prompt) {
    emit(KycPromptLoading());
    if (prompt.trim().isNotEmpty &&
        selectedPrompts.length < maxPrompts &&
        !selectedPrompts.contains(prompt.trim())) {
      customPrompts.add(prompt.trim());
      selectedPrompts.add(prompt.trim());
      _showBottomSheet = false;
      emit(KycPromptLoaded());
    }
  }

  void savePromptAnswer(
    String prompt,
    String answer, {
    String? audioPath,
    List<double>? waveformData,
    String? duration,
  }) {
    emit(KycPromptLoading());
    promptAnswers[prompt] = answer;
    if (audioPath != null) {
      promptAudioPaths[prompt] = audioPath;
      // Store waveform and duration for consistent preview
      if (waveformData != null && duration != null) {
        audioPromptData[prompt] = AudioPromptData(
          audioPath: audioPath,
          waveformData: waveformData,
          duration: duration,
        );
      }
    } else {
      promptAudioPaths.remove(prompt);
      audioPromptData.remove(prompt);
    }
    // Auto-select the prompt if not already selected
    if (!selectedPrompts.contains(prompt) &&
        selectedPrompts.length < maxPrompts) {
      selectedPrompts.add(prompt);
    }
    emit(KycPromptLoaded());
  }

  void editPromptAnswer(String prompt) {
    emit(KycPromptLoading());
    // This will be used to open the bottom sheet with existing answer
    emit(KycPromptLoaded());
  }

  String? getPromptAnswer(String prompt) {
    return promptAnswers[prompt];
  }

  String? getPromptAudioPath(String prompt) {
    return promptAudioPaths[prompt];
  }

  bool hasPromptAnswer(String prompt) {
    return promptAnswers.containsKey(prompt);
  }

  bool isPromptAnswerAudio(String prompt) {
    return promptAudioPaths.containsKey(prompt);
  }

  void removePrompt(String prompt) {
    emit(KycPromptLoading());
    selectedPrompts.remove(prompt);
    customPrompts.remove(prompt);
    emit(KycPromptLoaded());
  }

  bool isPromptSelected(String prompt) {
    return selectedPrompts.contains(prompt);
  }

  bool canSelectMore() {
    return selectedPrompts.length < maxPrompts;
  }

  AudioPromptData? getAudioPromptData(String prompt) {
    return audioPromptData[prompt];
  }

  bool isMaxReached() {
    return selectedPrompts.length >= maxPrompts;
  }
}
