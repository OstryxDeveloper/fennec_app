import 'package:fennac_app/app/theme/app_colors.dart';
import 'package:fennac_app/generated/assets.gen.dart';
import 'package:fennac_app/pages/kyc/presentation/bloc/cubit/kyc_prompt_cubit.dart';
import 'package:fennac_app/pages/kyc/presentation/bloc/state/kyc_prompt_state.dart';
import 'package:fennac_app/pages/kyc/presentation/widgets/prompt_audio_row.dart';
import 'package:fennac_app/widgets/custom_sized_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';

class AudioModeWidget extends StatelessWidget {
  final bool? isCustom;
  final String promptText;
  final String? existingAnswer;
  final String? existingAudioPath;
  final AudioPromptData? existingAudioData;
  const AudioModeWidget({
    super.key,
    this.isCustom = false,
    required this.promptText,
    this.existingAnswer,
    this.existingAudioPath,
    this.existingAudioData,
  });
  @override
  Widget build(BuildContext context) {
    final cubit = BlocProvider.of<KycPromptCubit>(context);
    return BlocBuilder<KycPromptCubit, KycPromptState>(
      bloc: cubit,
      builder: (context, state) {
        if (cubit.isRecorded) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 80,
                child: Center(child: _buildWaveformPreview(cubit)),
              ),
              const CustomSizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () async {
                      if (cubit.isPlaying) {
                        await cubit.pausePreview();
                      } else {
                        await cubit.playPreview();
                      }
                    },
                    child: Container(
                      width: 96,
                      height: 96,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: ColorPalette.primary,
                        shape: BoxShape.circle,
                      ),
                      child: cubit.isPlaying
                          ? const Icon(
                              Icons.stop,
                              color: Colors.white,
                              size: 32,
                            )
                          : SvgPicture.asset(
                              Assets.icons.play.path,
                              color: Colors.white,
                            ),
                    ),
                  ),
                  const CustomSizedBox(width: 24),
                  GestureDetector(
                    onTap: () {
                      cubit.deleteAudio();
                    },
                    child: Container(
                      width: 48,
                      height: 48,
                      alignment: Alignment.center,
                      child: SvgPicture.asset(
                        Assets.icons.trash.path,
                        width: 24,
                        height: 24,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        }

        // Recording UI
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 80,
              child: Center(child: _buildLiveWaveform(cubit)),
            ),
            const CustomSizedBox(height: 20),
            GestureDetector(
              onTap: () async {
                if (cubit.isRecording) {
                  await cubit.stopRecording();
                } else {
                  await cubit.startRecording();
                }
              },
              child: Container(
                width: 96,
                height: 96,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: cubit.isRecording ? Colors.red : ColorPalette.primary,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color:
                          (cubit.isRecording
                                  ? Colors.red
                                  : ColorPalette.primary)
                              .withOpacity(0.5),
                      blurRadius: 30,
                      spreadRadius: 10,
                    ),
                  ],
                ),
                child: cubit.isRecording
                    ? const Icon(Icons.stop, color: Colors.white, size: 40)
                    : SvgPicture.asset(
                        Assets.icons.mic.path,
                        width: 32,
                        height: 32,
                        color: Colors.white,
                      ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildWaveformPreview(KycPromptCubit cubit) {
    if (cubit.recordedWaveformData.isEmpty) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(40, (i) {
          final heights = [25.0, 35.0, 45.0, 30.0, 40.0, 50.0];
          return Container(
            width: 3,
            height: heights[i % heights.length],
            margin: const EdgeInsets.symmetric(horizontal: 1.5),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          );
        }),
      );
    }

    return PromptAudioRow(
      audioPath: cubit.recordingPath ?? "",
      waveformData: cubit.recordedWaveformData,
      height: 80,
      backgroundColor: Colors.transparent,
      playButtonColor: ColorPalette.primary,
      waveformColor: Colors.white,
    );
  }

  /// Build live waveform during recording - matches design image
  Widget _buildLiveWaveform(KycPromptCubit cubit) {
    final waveformData =
        cubit.waveformBuffer; // Access recording waveform (public getter)
    final barCount = 40;

    if (waveformData.isEmpty) {
      // Idle state - show placeholder bars
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(barCount, (i) {
          final heights = [15.0, 20.0, 25.0, 20.0, 15.0];
          return Container(
            width: 3,
            height: heights[i % heights.length],
            margin: const EdgeInsets.symmetric(horizontal: 1.5),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(1.5),
            ),
          );
        }),
      );
    }

    // Sample waveform data to fit bar count
    final step = waveformData.length / barCount;
    final sampledData = List.generate(barCount, (i) {
      final index = (i * step).floor().clamp(0, waveformData.length - 1);
      return waveformData[index];
    });

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: sampledData.map((amplitude) {
        // Map 0-1 amplitude to visual height (15-70px)
        final height = 15.0 + (amplitude.clamp(0.0, 1.0) * 55.0);
        return Container(
          width: 3,
          height: height,
          margin: const EdgeInsets.symmetric(horizontal: 1.5),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(1.5),
          ),
        );
      }).toList(),
    );
  }
}
