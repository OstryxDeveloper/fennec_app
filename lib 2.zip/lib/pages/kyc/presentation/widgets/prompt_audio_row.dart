import 'dart:math' as math;
import 'package:fennac_app/app/theme/app_colors.dart';
import 'package:fennac_app/app/theme/text_styles.dart';
import 'package:fennac_app/generated/assets.gen.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PromptAudioRow extends StatefulWidget {
  final String audioPath;
  final String duration;
  final List<double>? waveformData;
  final VoidCallback? onPlay;
  final Color? backgroundColor;
  final Color? playButtonColor;
  final Color? waveformColor;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? borderRadius;
  final double height;

  const PromptAudioRow({
    super.key,
    required this.audioPath,
    this.duration = '00:16',
    this.waveformData,
    this.onPlay,
    this.backgroundColor,
    this.playButtonColor,
    this.waveformColor,
    this.padding,
    this.borderRadius,
    this.height = 56,
  });

  @override
  State<PromptAudioRow> createState() => _PromptAudioRowState();
}

class _PromptAudioRowState extends State<PromptAudioRow> {
  late final AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  Duration? _duration;
  double _progress = 0.0; // 0..1 playback progress
  static const int _barCount = 30;
  List<double> _sampledData = const [];

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    _setupAudioPlayer();
  }

  Future<void> _setupAudioPlayer() async {
    try {
      // Set up audio source for playback
      final audioSource = ProgressiveAudioSource(Uri.file(widget.audioPath));
      await _audioPlayer.setAudioSource(audioSource);

      // Listen to playing state changes
      _audioPlayer.playingStream.listen((isPlaying) {
        if (mounted) {
          setState(() {
            _isPlaying = isPlaying;
          });
        }
      });

      // Listen to duration and position to animate waveform during playback
      _audioPlayer.durationStream.listen((d) {
        if (mounted) {
          setState(() {
            _duration = d;
          });
        }
      });

      _audioPlayer.positionStream.listen((pos) {
        final totalMs = _duration?.inMilliseconds ?? 0;
        if (mounted && totalMs > 0) {
          setState(() {
            _progress = (pos.inMilliseconds / totalMs).clamp(0.0, 1.0);
          });
        }
      });
    } catch (e) {
      debugPrint('Error setting up audio player: $e');
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Prepare sampled data once per build if not already set
    if (_sampledData.isEmpty && (widget.waveformData?.isNotEmpty ?? false)) {
      final step = widget.waveformData!.length / _barCount;
      _sampledData = List.generate(_barCount, (i) {
        final index = (i * step).floor().clamp(
          0,
          widget.waveformData!.length - 1,
        );
        return widget.waveformData![index];
      });
    }

    return Container(
      height: widget.height,
      padding:
          widget.padding ??
          const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: widget.backgroundColor ?? ColorPalette.secondry,
        borderRadius: widget.borderRadius ?? BorderRadius.circular(48),
      ),
      child: Row(
        children: [
          _buildPlayButton(),
          const SizedBox(width: 12),
          Expanded(child: _buildWaveform(context)),
          const SizedBox(width: 12),
          Text(widget.duration, style: AppTextStyles.bodySmall(context)),
        ],
      ),
    );
  }

  Widget _buildPlayButton() {
    return GestureDetector(
      onTap: () async {
        widget.onPlay?.call();

        if (_isPlaying) {
          await _audioPlayer.pause();
        } else {
          await _audioPlayer.play();
        }
      },
      child: Container(
        width: 48,
        height: 48,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.playButtonColor ?? ColorPalette.primary,
        ),
        child: SvgPicture.asset(
          _isPlaying ? Assets.icons.play.path : Assets.icons.play.path,
          width: 12,
          height: 15,
        ),
      ),
    );
  }

  Widget _buildWaveform(BuildContext context) {
    // If no waveform data provided, show placeholder bars
    if (widget.waveformData == null || widget.waveformData!.isEmpty) {
      return Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(20, (i) {
            final heights = [12.0, 18.0, 24.0, 18.0, 12.0];
            return Container(
              width: 2,
              height: heights[i % heights.length],
              margin: const EdgeInsets.symmetric(horizontal: 1),
              decoration: BoxDecoration(
                color: (widget.waveformColor ?? Colors.white).withOpacity(0.4),
                borderRadius: BorderRadius.circular(1),
              ),
            );
          }),
        ),
      );
    }
    // Active bar index based on playback progress
    final activeIndex = (_progress * _barCount).floor().clamp(0, _barCount - 1);

    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(_barCount, (i) {
          final amplitude = _sampledData.isNotEmpty
              ? _sampledData[i].clamp(0.0, 1.0)
              : 0.3;
          // Base height mapping (8-28px)
          double height = 8.0 + (amplitude * 20.0);

          // Emphasize the active bar and its neighbors for a dynamic effect
          final distance = (i - activeIndex).abs();
          if (_isPlaying) {
            // Gaussian bump around active index
            final sigma = 1.5; // spread of the bump
            final boost =
                6.0 * math.exp(-(distance * distance) / (2 * sigma * sigma));
            height += boost;
          }

          return Container(
            width: 2,
            height: height,
            margin: const EdgeInsets.symmetric(horizontal: 1),
            decoration: BoxDecoration(
              color: widget.waveformColor ?? Colors.white,
              borderRadius: BorderRadius.circular(1),
            ),
          );
        }),
      ),
    );
  }
}
